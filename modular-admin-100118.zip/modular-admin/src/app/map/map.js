document.addEventListener('DOMContentLoaded', function () {
    if (document.querySelectorAll('#map').length > 0)
    {
      if (document.querySelector('html').lang)
        lang = document.querySelector('html').lang;
      else
        lang = 'en';
  
      var js_file = document.createElement('script');
      js_file.type = 'text/javascript';
      js_file.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDXK8-qqVdFN1ucsMUEukrI6S4wmtGNbKI&callback=initMap';
      document.getElementsByTagName('head')[0].appendChild(js_file);
    }
  });


var map;
var markers = [];
var infowindow = null;
var infowincontent;
function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 8,
    center: new google.maps.LatLng(50.04,21.98),
    mapTypeId: 'terrain'
  });

  var script = document.createElement('script');
  console.log("przed pobraniem jsona");
  $.get('http://94.177.230.159/rsp/controller/map/points.php', function(jsonData) {

    jsonD = JSON.parse(JSON.stringify(jsonData));

    setMarkers(map, jsonD);
    infowindow = new google.maps.InfoWindow({
      content: "loading..."
    });
    

  });
}

function setMarkers(map, obj1){
  for (var i=0; i<obj1.features.length; i++){
    var coords = obj1.features[i].geometry.coordinates;
    var latLng = new google.maps.LatLng(coords[0],coords[1]);
    var id = obj1.features[i].id;
    var marker = new google.maps.Marker({
      position: latLng,
      map: map,
      store_id : id,
      html: "test data"
    });
    
    var dataToView = "jeszcze nie pobrano";
    google.maps.event.addListener(marker, 'click', function () {
      // where I have added .html to the marker object.
      var id = this.get('store_id');
      var handle = this;
      var json;
      $.get("http://94.177.230.159/rsp/controller/map/point_info.php?id_sensor=" + id, function(Data){
        json = JSON.parse(JSON.stringify(Data));
        if (!json.length){
          dataToView = "Czujnik: " + json.id + '<br>' +
          '<b>'+ "Tempearatura = " + json.value.temperature +'<br>' +
          "Wilgotność = " + json.value.humidity + '<br>' +
          "ciśnienie = " + json.value.pressure + '<br>' +
          "PM2 = " + json.value.pm2 + '</b>';
        }
        else{
          dataToView = '<b>' + 'BRAK DANYCH' + '</b>';
        }
        infowindow.setContent(dataToView);
        infowindow.open(map, handle);

        
        // Wyswietl wykres
        drawMorrisCharts(id);
       
      });




    });

  }
}



