document.addEventListener('DOMContentLoaded', function () {
    if (document.querySelectorAll('#map2').length > 0)
    {
      if (document.querySelector('html').lang)
        lang = document.querySelector('html').lang;
      else
        lang = 'en';
  
      var js_file = document.createElement('script');
      js_file.type = 'text/javascript';
      js_file.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDXK8-qqVdFN1ucsMUEukrI6S4wmtGNbKI&callback=initMap';
      document.getElementsByTagName('head')[0].appendChild(js_file);
    }


    $.get("http://94.177.230.159/rsp/controller/table/devices_table.php", function(Data){
       
		injson = JSON.parse(JSON.stringify(Data));
		$.each(injson.features , function (index, value){
			var option = document.createElement("option");
			option.text = "Czujnik " + String(index+1);
			option.value = String(index+1);
			var select = document.getElementById("select-settings1");
			select.appendChild(option); 
		});
	});

  });

    var infowindow = null

     // global "map" variable
     var map = null;
     var marker = null;

// A function to create the marker and set up the event window function 
function createMarker(latlng, name, html) {
    var contentString = html;
    var marker = new google.maps.Marker({
        position: latlng,
        map: map,
        zIndex: Math.round(latlng.lat()*-100000)<<5
        });

    google.maps.event.addListener(marker, 'click', function() {
        infowindow.setContent(contentString); 
        infowindow.open(map,marker);

        // Enter latlng data to form
        var lat = document.getElementById('latitude');
        lat.setAttribute('value', latlng.lat());
        var lat = document.getElementById('longitude');
        lat.setAttribute('value', latlng.lng());

        });
    google.maps.event.trigger(marker, 'click');    
    return marker;
}


function initMap() {

    infowindow = new google.maps.InfoWindow(
        { 
            size: new google.maps.Size(150,50)
        });
    // create the map
    var myOptions = {
        zoom: 8,
        center: new google.maps.LatLng(50.04,21.98),
        mapTypeControl: true,
        mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
        navigationControl: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    map = new google.maps.Map(document.getElementById("map2"),
                                    myOptions);
  
    google.maps.event.addListener(map, 'click', function() {
        infowindow.close();
        });

    google.maps.event.addListener(map, 'click', function(event) {
	//call function to create marker
        if (marker) {
            marker.setMap(null);
            marker = null;
        }
	    marker = createMarker(event.latLng, "name", "<b>Location</b><br>"+event.latLng);
    });
}

function showSettingsData(){
    var e = document.getElementById("select-settings1");
	var strUser = e.options[e.selectedIndex].value;
	var injson;
	$.get("http://94.177.230.159/rsp/controller/device/device_settings_get.php?id_sensor=" + strUser, function(Data){
		
        injson = JSON.parse(JSON.stringify(Data));
        var lat = document.getElementById('latitude');
        var lng = document.getElementById('longitude');
        var alt = document.getElementById('altitude');

        document.getElementById('sensor_id').value = strUser;


        lng.setAttribute('value', injson.features[0].longitude);
        lat.setAttribute('value', injson.features[0].latitude);
        alt.setAttribute('value', injson.features[0].height);
        if(injson.features[0].Temperature == 1){
            document.getElementById('input-temp').checked = true;
        }else{
            document.getElementById('input-temp').checked = false;
        }
        if(injson.features[0].Humidity == 1){
            document.getElementById('input-humid').checked = true;
        }else{
            document.getElementById('input-humid').checked = false;
        }
        if(injson.features[0].Pressure == 1){
            document.getElementById('input-press').checked = true;
        }else{
            document.getElementById('input-press').checked = false;
        }
        if(injson.features[0].PM == 1){
            document.getElementById('input-pm2').checked = true;
        }else{
            document.getElementById('input-pm2').checked = false;
        }
        

    });
}

function settings_on_click(){
    $.post( 'http://94.177.230.159/rsp/controller/device/update_device_setting.php', $('form#settings-form').serialize(), function(data) {
		console.log(data);
		if(data.length < 3){
			alert("zapisano");
		}
		else{
			alert("nie zapisano");
		}
		
	});
}