$(function(){
	$.get("http://94.177.230.159/rsp/controller/table/devices_table.php", function(Data){
       
		injson = JSON.parse(JSON.stringify(Data));
		$.each(injson.features , function (index, value){
			var option = document.createElement("option");
			option.text = "Czujnik " + String(index+1);
			option.value = String(index+1);
			var select = document.getElementById("select1");
			select.appendChild(option); 
		});
	});
})


function createTableFromJSON(){

	var e = document.getElementById("select1");
	var strUser = e.options[e.selectedIndex].value;
	var injson;
	$.get("http://94.177.230.159/rsp/controller/table/point_table.php?id_sensor=" + strUser, function(Data){
		
		injson = JSON.parse(JSON.stringify(Data));

	var col = [];
	for (var i = 0; i < injson.features.length; i++) {
		for (var key in injson.features[i]) {
			if (col.indexOf(key) === -1) {
				col.push(key);
				
			}
		}
	}

	var table = document.getElementById("dataTable");


	while(table.rows.length > 1) {
		table.deleteRow(1);
	}



	var tr = table.insertRow(-1);

	for (var i=0; i<injson.features.length; i++){
		tr = table.insertRow(-1);

		for (var j=0; j<col.length; j++){
			var tabCell = tr.insertCell(-1);
			tabCell.innerHTML = injson.features[i][col[j]];
		}
	}

	var divContainer = document.getElementById("showData");
	divContainer.innerHTML = "";
	divContainer.appendChild(table);


	});
}

function drawMorrisCharts(d_id) {

	$('#morris-line-chart-temp').empty();
	$('#morris-line-chart-humid').empty();
	$('#morris-line-chart-press').empty();
	$('#morris-line-chart-pm2').empty();
	
	$.get("http://94.177.230.159/rsp/controller/table/point_table.php?id_sensor=" + d_id, function(Data){
		
		injson = JSON.parse(JSON.stringify(Data));

		var data_plot_temp = [];
		var data_plot_humid = [];
		var data_plot_press = [];
		var data_plot_pm2 = [];
		
		
		for (var j=0; j<injson.features.length; j++){
			data_plot_temp.push({
				year: injson.features[j].date_time,
				value: injson.features[j].temperature
			});
		}
		temp_min = min(data_plot_temp)-0.1;
		temp_max = max(data_plot_temp)+0.1;

		for (var j=0; j<injson.features.length; j++){
			data_plot_humid.push({
				year: injson.features[j].date_time,
				value: injson.features[j].humidity
			});
		}
		humid_min = min(data_plot_humid)-0.1;
		humid_max = max(data_plot_humid)+0.1;

		for (var j=0; j<injson.features.length; j++){
			data_plot_press.push({
				year: injson.features[j].date_time,
				value: injson.features[j].pressure
			});
		}
		press_min = min(data_plot_press)-0.1;
		press_max = max(data_plot_press)+0.1;

		for (var j=0; j<injson.features.length; j++){
			data_plot_pm2.push({
				year: injson.features[j].date_time,
				value: injson.features[j].pm2
			});
		}
		pm2_min = min(data_plot_pm2)-0.1;
		pm2_max = max(data_plot_pm2)+0.1;

		Morris.Line({
			element: 'morris-line-chart-temp',
				data: data_plot_temp,
			xkey: 'year',
			ykeys: ['value'],
			ymax: temp_max,
			ymin: temp_min,
			resize: true,
			lineWidth:4,
			labels: ['Temperatura'],
			lineColors: [config.chart.colorPrimary.toString()],
			pointSize:5,
	
		});	

		Morris.Line({
			element: 'morris-line-chart-humid',
				data: data_plot_humid,
			xkey: 'year',
			ykeys: ['value'],
			ymax: humid_max,
			ymin: humid_min,
			resize: true,
			lineWidth:4,
			labels: ['Wilgotność'],
			lineColors: [config.chart.colorPrimary.toString()],
			pointSize:5,
	
		});
		
		Morris.Line({
			element: 'morris-line-chart-press',
				data: data_plot_press,
			xkey: 'year',
			ykeys: ['value'],
			ymax: press_max,
			ymin: press_min,
			resize: true,
			lineWidth:4,
			labels: ['Ciśnienie'],
			lineColors: [config.chart.colorPrimary.toString()],
			pointSize:5,
	
		});	

		Morris.Line({
			element: 'morris-line-chart-pm2',
				data: data_plot_pm2,
			xkey: 'year',
			ykeys: ['value'],
			ymax: pm2_max,
			ymin: pm2_min,
			resize: true,
			lineWidth:4,
			labels: ['PM2'],
			lineColors: [config.chart.colorPrimary.toString()],
			pointSize:5,
	
		});	


	});
}
	
function min(object){
	var minimum = object[0].value;

	for (var j=0; j<object.length; j++){
		if ( object[j].value < minimum){
			minimum = object[j].value;
		}
	}
	return minimum;
}

function max(object){
	var maximum = object[0].value;

	for (var j=0; j<object.length; j++){
		if ( object[j].value > maximum){
			maximum = object[j].value;
		}
	}
	return maximum;
}