$(function(){
    $.get("http://94.177.230.159/rsp/controller/login/user_info.php", function(Data){
        var json = JSON.parse(Data);
        if(json.logged == null) json.logged = false;   
        user_logged_in = true;
        var dropdown = document.getElementById("drop_down_login_menu");
        var name = document.getElementById('user_name');
        if (json.logged){
            
            name.innerHTML = json.user_name;
            var first_node  = document.createElement("a");
            first_node.setAttribute('class',  'dropdown-item');
            first_node.setAttribute('href',  'settings.html');
            first_node.setAttribute('id',  'setting_option');
    
            var node = document.createElement("i");
            node.setAttribute('class', 'fa fa-gear icon');    
            first_node.appendChild(node);
            first_node.innerHTML += "Ustawienia";
            dropdown.appendChild(first_node);
    
    
            first_node = document.createElement("a");
            first_node.setAttribute('class',  'dropdown-item');
            first_node.setAttribute('href',  'javascript:logout()');
            first_node.setAttribute('id',  'login_option');
            node = document.createElement("i");
            node.setAttribute('class', 'fa fa-power-off icon');
            first_node.appendChild(node);
            first_node.innerHTML += "Wyloguj się";
            dropdown.appendChild(first_node);
    
    
        }
        else{
    
            name.innerHTML = "Logowanie";
            var first_node  = document.createElement("a");
            first_node.setAttribute('class',  'dropdown-item');
            first_node.setAttribute('href',  'login.html');
            first_node.setAttribute('id',  'login_option');
    
            node = document.createElement("i");
            node.setAttribute('class', 'fa fa-power-off icon');
            first_node.appendChild(node);
            first_node.innerHTML += "Zaloguj się";
            dropdown.appendChild(first_node);
    
        }

    });

    
    
});

function logout(){
    
    $.post("http://94.177.230.159/rsp/controller/login/logout.php")
    alert("Wylogowano");
    window.location.replace("index.html");
}