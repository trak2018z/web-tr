//SignupForm validation
$(function() {
	if (!$('#signup-form').length) {
        return false;
    }

    var signupValidationSettings = {
	    rules: {
	    	username: {
	    		required: true,
	    	},
	        email: {
	            required: true,
	            email: true
	        },
	        password: {
				required: true,
				minlength: 6
	        },
	        confirm_password: {
				required: true,
				minlength: 6,
				equalTo: "#password"
			},
			agree: {
				required: true,
			}
	    },
	    groups: {
	    	username: "username",
			pass: "password confirm_password",
		},
		errorPlacement: function(error, element) {
			if (
				element.attr("username") == "password" || 
				element.attr("username") == "confirm_password" 
			) {
				error.insertAfter($("#confirm_password").closest('.row'));
				element.parents("div.form-group")
				.addClass('has-error');
			}
			else if (element.attr("username") == "agree") {
				error.insertAfter("#agree-text");
			}
			else {
				error.insertAfter(element);
			}
		},
	    messages: {
	    	username: "Please enter firstname and lastname",
	        email: {
	            required: "Please enter email",
	            email: "Please enter a valid email address"
	        },
	        password: {
	        	required: "Please enter password fields.",
	        	minlength: "Passwords should be at least 6 characters."
	        },
	        confirm_password: {
	        	required: "Please enter password fields.",
	        	minlength: "Passwords should be at least 6 characters."
	        },
	        agree: "Please accept our policy"
	    },
	    invalidHandler: function() {
			animate({
				name: 'shake',
				selector: '.auth-container > .card'
			});
		}
	}

	$.extend(signupValidationSettings, config.validations);

    $('#signup-form').validate(signupValidationSettings);
});

function signup_on_click(){
	$.post( 'http://94.177.230.159/rsp/controller/login/register.php', $('form#signup-form').serialize(), function(data) {
		console.log(data);
		if(data.length < 3){
			alert("zarejestrowano");
			window.location.replace("index.html");
		}
		else{
			alert("nie zarejestrowano");
		}
		
	});
}