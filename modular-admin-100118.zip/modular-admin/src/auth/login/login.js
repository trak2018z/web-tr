//LoginForm validation
$(function() {
	if (!$('#login-form').length) {
        return false;
    }

    var loginValidationSettings = {
	    rules: {
	        username: {
	            required: true,
	            email: false
	        },
	        password: "required",
	        agree: "required"
	    },
	    messages: {
	        username: {
	            required: "Please enter username",
	            email: "Please enter a valid email address"
	        },
	        password:  "Please enter password",
	        agree: "Please accept our policy"
	    },
	    invalidHandler: function() {
			animate({
				name: 'shake',
				selector: '.auth-container > .card'
			});
		}
	}

	$.extend(loginValidationSettings, config.validations);

    $('#login-form').validate(loginValidationSettings);
})

function submit_on_click(){
	console.log("przed postem");
	$.post( 'http://94.177.230.159/rsp/controller/login/login.php', $('form#login-form').serialize(), function(data) {
		if(data.length < 3){
			alert("zalogowano");
			window.location.replace("index.html");
		}
		else{
			alert("zle haslo");
		}
		
	});
}