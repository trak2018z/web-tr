$(function(){
	

if( true ){
	$("div.anonymous").show();
}

if( false ){
	$("div.logged_in").show();
}

})